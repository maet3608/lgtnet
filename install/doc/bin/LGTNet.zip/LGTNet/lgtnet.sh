#!/bin/bash
java -Xmx1200M -jar LGTNet.jar "$@"